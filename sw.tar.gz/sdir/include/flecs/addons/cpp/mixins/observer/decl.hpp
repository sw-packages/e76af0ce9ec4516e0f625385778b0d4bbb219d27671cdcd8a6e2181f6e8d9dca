#pragma once

namespace flecs {

struct observer;

template<typename ... Components>
struct observer_builder;

}
